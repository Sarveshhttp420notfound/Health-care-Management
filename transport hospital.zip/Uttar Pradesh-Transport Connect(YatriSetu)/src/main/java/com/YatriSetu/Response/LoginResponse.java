package com.YatriSetu.Response;

public class LoginResponse {
	
	private Integer userid;
	private String name;
	private String userType;
	private DashBoardResponse dashboardResponse;
    private boolean isValidLogin;
    private boolean pwdChanged;
	public Integer getUserid() {
		return userid;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public DashBoardResponse getDashboardResponse() {
		return dashboardResponse;
	}
	public void setDashboardResponse(DashBoardResponse dashboardResponse) {
		this.dashboardResponse = dashboardResponse;
	}
	public boolean isValidLogin() {
		return isValidLogin;
	}
	public void setValidLogin(boolean isValidLogin) {
		this.isValidLogin = isValidLogin;
	}
	public boolean isPwdChanged() {
		return pwdChanged;
	}
	public void setPwdChanged(boolean pwdChanged) {
		this.pwdChanged = pwdChanged;
	}
	
	
    
}
