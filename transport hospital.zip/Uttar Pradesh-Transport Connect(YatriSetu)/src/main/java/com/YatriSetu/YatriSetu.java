package com.YatriSetu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YatriSetu {

	public static void main(String[] args) {
		SpringApplication.run(YatriSetu.class, args);
	}

}
