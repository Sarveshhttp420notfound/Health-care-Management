package com.YatriSetu.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.YatriSetu.Request.LoginRequest;
import com.YatriSetu.Request.PwdChangeRequest;
import com.YatriSetu.Request.SignUpRequest;
import com.YatriSetu.Response.LoginResponse;
import com.YatriSetu.service.UserService;

@RestController
public class UserRestController {
	@Autowired
	private UserService service;
	
	@PostMapping("/user")
	public ResponseEntity<String> userRegistration(@RequestBody SignUpRequest request){
		try{
			boolean isSaved=service.saveUser(request);
			if(isSaved) {
				return new ResponseEntity<>("Registration Sucess",HttpStatus.OK);
			}
			else {
				return new ResponseEntity<>("Registration Failed",HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}catch(Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>("Registration Failed: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
		
	}
	
	@PostMapping("/login")
	public ResponseEntity<LoginResponse>userLogin(@RequestBody LoginRequest request){
		LoginResponse response=service.userLogin(request);
		return new ResponseEntity<>(response,HttpStatus.OK);
	}
	
	@PostMapping("/pwd-change")
	public ResponseEntity<LoginResponse>updatePwd(PwdChangeRequest request){
		LoginResponse login=service.updatePwd(request);
		return new ResponseEntity<>(login,HttpStatus.OK);
	}
	
	
	@GetMapping("/recover-pwd/{email}")
	public ResponseEntity<String>recoverPwd(@PathVariable String email){
		boolean isValid=service.recoverPwd(email);
		if(isValid) {
			return new ResponseEntity<>("Password sent  to your email",HttpStatus.OK);
		}else {
			return new ResponseEntity<>("Invalid Email",HttpStatus.BAD_REQUEST);
		}
	}
	
	
}
	
	
	
	
	
	


