package com.YatriSetu.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;
import jakarta.mail.internet.MimeMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import jakarta.mail.internet.MimeMessage;

//import jakarta.mail.internet.MimeMessage;

@Component
public class EmailUtils {
	@Autowired
	private JavaMailSender mailSender;//(String to,String subject,String body) {
		
	
	public boolean sendEmail(String to,String subject,String body) {
		boolean isSent=false;
		try {
				MimeMessage mimeMsg=mailSender.createMimeMessage();
				MimeMessageHelper helper=new MimeMessageHelper(mimeMsg);
		        helper.setTo(to);
		        helper.setSubject(subject);
		        helper.setText(body,true);
		        mailSender.send(mimeMsg);
		        isSent=true;
		        
		}catch(Exception e) {
			e.printStackTrace();
		}
		return isSent;
	}

}

