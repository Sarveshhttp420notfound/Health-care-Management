package com.YatriSetu.Entity;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name="USER_INFO")
public class UserInfoEntity {
	@JsonIgnore 
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
  private Integer userid;
  private String name;
  private String email;
  private String pwd;
  private String gender;
  private LocalDate dob;
  private Long phnno;
  private Long ssn;
  private String userType;
  private String pwdChanged;
public Integer getUserid() {
	return userid;
}
public void setUserid(Integer userid) {
	this.userid = userid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public LocalDate getDob() {
	return dob;
}
public void setDob(LocalDate dob) {
	this.dob = dob;
}
public Long getPhnno() {
	return phnno;
}
public void setPhnno(Long phnno) {
	this.phnno = phnno;
}
public Long getSsn() {
	return ssn;
}
public void setSsn(Long ssn) {
	this.ssn = ssn;
}
public String getUserType() {
	return userType;
}
public void setUserType(String userType) {
	this.userType = userType;
}
public String getPwdChanged() {
	return pwdChanged;
}
public void setPwdChanged(String pwdChanged) {
	this.pwdChanged = pwdChanged;
}
  
 
  
}
 