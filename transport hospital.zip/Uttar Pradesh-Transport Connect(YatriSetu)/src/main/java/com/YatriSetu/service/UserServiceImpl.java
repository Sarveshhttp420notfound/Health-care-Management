package com.YatriSetu.service;

import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import com.YatriSetu.Response.DashBoardResponse;
import com.YatriSetu.Entity.UserInfoEntity;
import com.YatriSetu.Request.LoginRequest;
import com.YatriSetu.Request.PwdChangeRequest;
import com.YatriSetu.Request.SignUpRequest;
import com.YatriSetu.Response.LoginResponse;
import com.YatriSetu.Response.SignUpResponse;
import com.YatriSetu.repo.UserInfoRepository;
import com.YatriSetu.utils.EmailUtils;

import io.micrometer.core.ipc.http.HttpSender.Response;

@Service
public class UserServiceImpl implements UserService {
   @Autowired
	private UserInfoRepository userRepo;
   
   
   @Autowired
   private EmailUtils emailUtils;
	
	@Override
	public boolean saveUser(SignUpRequest request) {
		SignUpResponse reponse=new SignUpResponse();
		
		if(userRepo.findByEmail(request.getEmail()) != null) {
		        throw new RuntimeException("Email already exists");
		    }

		String tempPwd=generateTempPwd();
		request.setPwd(tempPwd);
		request.setPwdChanged("false");
		
		UserInfoEntity entity=new UserInfoEntity();
		BeanUtils.copyProperties(request, entity,"userid");
		userRepo.save(entity);
		
		try {
			String subject="IES-Account Created ";
		    String body="Your Pwd To Login ::"+tempPwd;
		    boolean isSent= emailUtils.sendEmail(request.getEmail(),subject,body);
		// return	
		}catch(Exception e) {
			e.printStackTrace();
		}
		return true;
		
		//boolean isSent=
		 //(isSent)?true:false;
	}
	

	@Override
	public LoginResponse userLogin(LoginRequest request) {
		LoginResponse response=new LoginResponse();
		
		UserInfoEntity entity=new UserInfoEntity();
		entity.setEmail(request.getEmail());
		entity.setPwd(request.getPwd());
		Example<UserInfoEntity>of=Example.of(entity);
		List<UserInfoEntity> entities=userRepo.findAll(of);
		if(!entities.isEmpty()) {
			UserInfoEntity user=entities.get(0);
			response.setUserid(user.getUserid());
			response.setUserType(user.getUserType());
			if(user.getPwdChanged().equals("true")) {
				//Second Login
				response.setPwdChanged(true);
				response.setValidLogin(true);
				
				//set Dashboard data
				DashBoardResponse dashboard=new DashBoardResponse();
				dashboard.setPlansCount(6l);
				dashboard.setBenefitAmtTotal(3400.00);
				dashboard.setCitizensApCnt(1000l);
				dashboard.setCitizensDnCnt(500l);
				
				response.setDashboardResponse(dashboard);
				
			}else {
				response.setPwdChanged(false);
				response.setValidLogin(true);
				//First Login
			}		
			
		}
		else {
			response.setValidLogin(false);
		}
		return response;
	}

	@Override
	public LoginResponse updatePwd(PwdChangeRequest request) {
		LoginResponse response=new LoginResponse();
		
		Integer userId=request.getUserId();
		Optional<UserInfoEntity> findById=userRepo.findById(userId);
		if(findById.isPresent()) {
			UserInfoEntity entity=findById.get();
			entity.setPwd(request.getPwd());
			entity.setPwdChanged("true");
			userRepo.save(entity);
			
			//construct dashboard response 
			response.setUserid(entity.getUserid());
			response.setUserType(entity.getUserType());
			response.setValidLogin(true);
			DashBoardResponse dashboard=new DashBoardResponse();
			dashboard.setPlansCount(6l);
			dashboard.setBenefitAmtTotal(3400.00);
			dashboard.setCitizensApCnt(1000l);
			dashboard.setCitizensDnCnt(500l);
			response.setDashboardResponse(null);
		}
		return response;
	}

	@Override
	public boolean recoverPwd(String email) {
		UserInfoEntity user=userRepo.findByEmail(email);
		if(user==null) {
			return false;
		}
		
		
		
		String subject="IES- Recover Password";
		String body="Your Password:: "+user.getPwd();
		return emailUtils.sendEmail(email, subject, body);
		
	}
	
	public String generateTempPwd() {
		
		    // create a string of all characters
		    String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789";

		    // create random string builder
		    StringBuilder sb = new StringBuilder();

		    // create an object of Random class
		    Random random = new Random();

		    // specify length of random string
		    int length = 5;

		    for(int i = 0; i < length; i++) {

		      // generate random index number
		      int index = random.nextInt(alphabet.length());

		      // get character specified by index
		      // from the string
		      char randomChar = alphabet.charAt(index);

		      // append the character to string builder
		      sb.append(randomChar);
		    }

		    return sb.toString();
		   

		  }
		
	}


