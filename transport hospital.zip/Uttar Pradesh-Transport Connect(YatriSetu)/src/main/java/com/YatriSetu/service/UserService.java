package com.YatriSetu.service;

import com.YatriSetu.Request.LoginRequest;
import com.YatriSetu.Request.PwdChangeRequest;
import com.YatriSetu.Request.SignUpRequest;
import com.YatriSetu.Response.LoginResponse;

public interface UserService {
	
	public boolean saveUser (SignUpRequest request);
	
	public LoginResponse userLogin(LoginRequest request);
	
	public LoginResponse updatePwd(PwdChangeRequest request);
    
	public boolean recoverPwd(String email);	
}
