package com.YatriSetu.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.YatriSetu.Entity.UserInfoEntity;

public interface UserInfoRepository extends JpaRepository<UserInfoEntity,Integer>{
	
    public UserInfoEntity findByEmail(String email);
	

}
