package com.example.Transport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YatriSetuTests {

	@Test
	void contextLoads() {
	}

}
