package com.example.APPLICATION_REGISTRATION.service;

import java.util.List;

import com.example.APPLICATION_REGISTRATION.Binding.CitizenApp;

public interface AppRegService {
	
	public String createCitizenApp(CitizenApp  app);
	
	public List<CitizenApp> getApplications(Integer userId,String userType);

}
