package com.example.demo.Service;

import java.util.Map;

import com.example.demo.binding.Education;
import com.example.demo.binding.Income;
import com.example.demo.binding.Kids;
import com.example.demo.binding.PlanSelection;
import com.example.demo.binding.Summary;
public interface DcService {
	
	public Map<Integer,String> getPlanNames();
	
	public boolean updatePlanSelection(PlanSelection planSe1);
	
	public boolean saveIncome(Income income);
	
	public boolean saveEducation(Education edu);
	
	public boolean saveKids(Kids kids);
	public Summary getSummaryInfo(Integer caseNum);

}
