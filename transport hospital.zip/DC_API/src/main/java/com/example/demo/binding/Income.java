package com.example.demo.binding;

public class Income {

}
