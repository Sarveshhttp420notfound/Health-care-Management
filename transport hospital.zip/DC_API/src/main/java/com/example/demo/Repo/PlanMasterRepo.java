package com.example.demo.Repo;

public interface PlanMasterRepo {

}
