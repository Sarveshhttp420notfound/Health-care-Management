package com.example.demo.binding;

public class Kids {

}
